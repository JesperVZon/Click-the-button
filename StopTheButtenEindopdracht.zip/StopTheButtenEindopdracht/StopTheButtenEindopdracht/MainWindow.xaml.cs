﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace StopTheButtenEindopdracht
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double Timerspeed = 1.0;
        int TimerTick = 0;

        DispatcherTimer myTimer = new DispatcherTimer();
        DispatcherTimer myPlayTimer = new DispatcherTimer();
        DispatcherTimer myPartyTimer = new DispatcherTimer();
        private static Random random = new Random();
        static int myPlayTime = 0;
        public MainWindow()
        {
            InitializeComponent();
            CmbImage.SelectedIndex = 0;
            TimerMethod();
            TimerPlayMethod();
            TimerPartyMethod();
            ImageClick.IsEnabled = false;
            CmbImage.IsEnabled = true;
            this.Width = System.Windows.SystemParameters.PrimaryScreenWidth;
            this.Height = System.Windows.SystemParameters.PrimaryScreenHeight;
        }

        private void MyPartyTimer_Tick(object sender, EventArgs e)
        {
            TimerTick++;
            this.Height -= 5;
            this.Width -= 5.5;
            if (TimerTick >= 100)
            {
                myPlayTimer.Stop();
                myPartyTimer.Stop();
                BtnStart.IsEnabled = true;
                this.Width = System.Windows.SystemParameters.PrimaryScreenWidth;
                this.Height = System.Windows.SystemParameters.PrimaryScreenHeight;
                MessageBox.Show("Helaas, je hebt de party mode niet gehaald");
                TimerTick = 0;
                myPlayTime = 0;
            }

            double minLeft = 0;
            double maxLeft = SecondGrid.ActualWidth - ImageClick.ActualWidth;
            double minTop = 0;
            double maxTop = SecondGrid.ActualHeight - ImageClick.ActualHeight;


            double left = RandomBetween(minLeft, maxLeft);
            double top = RandomBetween(minTop, maxTop);
            ImageClick.Margin = new Thickness(left, top, 0, 0);
            this.WindowStartupLocation = WindowStartupLocation.Manual;
        }

        private void MyPlayTimer_Tick(object sender, EventArgs e)
        {
            myPlayTime++;
        }

        private void CmbImage_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string ImageCharacter = ((ComboBoxItem)CmbImage.SelectedItem).Content.ToString();

            switch (ImageCharacter)
            {
                case "Roadrunner":
                    ImageClick.Source = new BitmapImage(new Uri("Pack://application:,,,/Afbeeldingen/roadrunner.jpg"));
                    break;
                case "Rock":
                    ImageClick.Source = new BitmapImage(new Uri("Pack://application:,,,/Afbeeldingen/Rock.jpg"));
                    break;
                case "Speedy":
                    ImageClick.Source = new BitmapImage(new Uri("Pack://application:,,,/Afbeeldingen/Speedy.jpg"));
                    break;
                case "M dot R":
                    ImageClick.Source = new BitmapImage(new Uri("Pack://application:,,,/Afbeeldingen/BigBomboclat.jpg"));
                    break;
                case "Mr. Krabs":
                    ImageClick.Source = new BitmapImage(new Uri("Pack://application:,,,/Afbeeldingen/Krabs.png"));
                    break;
                case "King":
                    ImageClick.Source = new BitmapImage(new Uri("Pack://application:,,,/Afbeeldingen/hihihiha.jpg"));
                    break;
            }
        }




        private void MyTimer_Tick(object sender, EventArgs e)
        {
            double minLeft = 0;
            double maxLeft = SecondGrid.ActualWidth - ImageClick.ActualWidth;
            double minTop = 0;
            double maxTop = SecondGrid.ActualHeight - ImageClick.ActualHeight;


            double left = RandomBetween(minLeft, maxLeft);
            double top = RandomBetween(minTop, maxTop);
            ImageClick.Margin = new Thickness(left, top, 0, 0);
        }

        private double RandomBetween(double min, double max)
        {
            return random.NextDouble() * (max - min) + min;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            myPlayTime = 0;
            myTimer.Start();
            myPlayTimer.Start();
            ImageClick.IsEnabled = true;
            CmbImage.IsEnabled = false;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Timerspeed -= 0.2;
            if (Timerspeed < 0.1)
            {
                Timerspeed = 0.1;
            }
            TimerMethod();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

            Timerspeed += 0.2;
            if (Timerspeed > 2.0)
            {
                Timerspeed = 2.0;
            }
            TimerMethod();
        }
        private void TimerMethod()
        {
            this.Loaded += MyTimer_Tick;
            myTimer.Interval = TimeSpan.FromSeconds(Timerspeed);
            myTimer.Tick += MyTimer_Tick;

        }
        private void TimerPlayMethod()
        {
            this.Loaded += MyPlayTimer_Tick;
            myPlayTimer.Interval = TimeSpan.FromSeconds(1);
            myPlayTimer.Tick += MyPlayTimer_Tick;

        }
        private void TimerPartyMethod()
        {
            this.Loaded += MyPartyTimer_Tick;
            myPartyTimer.Interval = TimeSpan.FromSeconds(0.3);
            myPartyTimer.Tick += MyPartyTimer_Tick;

        }
        private void ImageClick_MouseDown(object sender, MouseButtonEventArgs e)
        {
            myTimer.Stop();
            myPlayTimer.Stop();
            myPartyTimer.Stop();
            CmbImage.IsEnabled = true;
            ImageClick.IsEnabled = false;
            BtnStart.IsEnabled = true;
            this.Hide();
            Secondwindow gewonnen = new Secondwindow(myPlayTime);
            gewonnen.ShowDialog();
            this.Show();
            myPlayTime = 0;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            myPartyTimer.Start();
            myPlayTimer.Start();

            ImageClick.IsEnabled = true;
            CmbImage.IsEnabled = false;
            BtnStart.IsEnabled = false;
        }
    }
}


